package com.example.fifa_kotlin

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class FifaKotlinApplicationTests {

	@Test
	fun contextLoads() {
	}

}
