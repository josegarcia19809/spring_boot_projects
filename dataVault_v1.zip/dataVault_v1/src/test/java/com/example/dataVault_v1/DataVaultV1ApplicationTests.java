package com.example.dataVault_v1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataVaultV1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
