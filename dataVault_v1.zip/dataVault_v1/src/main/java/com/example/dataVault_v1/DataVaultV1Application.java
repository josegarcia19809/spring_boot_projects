package com.example.dataVault_v1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataVaultV1Application {

	public static void main(String[] args) {
		SpringApplication.run(DataVaultV1Application.class, args);
	}

}
