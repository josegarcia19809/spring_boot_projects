package com.example.gestion_vacantes_db;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionVacantesDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionVacantesDbApplication.class, args);
	}

}
