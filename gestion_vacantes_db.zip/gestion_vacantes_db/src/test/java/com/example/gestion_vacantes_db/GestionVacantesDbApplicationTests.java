package com.example.gestion_vacantes_db;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionVacantesDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
