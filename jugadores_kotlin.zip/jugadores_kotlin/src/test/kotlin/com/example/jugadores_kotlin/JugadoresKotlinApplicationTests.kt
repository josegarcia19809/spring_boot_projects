package com.example.jugadores_kotlin

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class JugadoresKotlinApplicationTests {

	@Test
	fun contextLoads() {
	}

}
