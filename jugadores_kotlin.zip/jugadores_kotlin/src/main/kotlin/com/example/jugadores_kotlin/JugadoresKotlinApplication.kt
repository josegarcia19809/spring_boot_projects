package com.example.jugadores_kotlin

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class JugadoresKotlinApplication

fun main(args: Array<String>) {
	runApplication<JugadoresKotlinApplication>(*args)
}
