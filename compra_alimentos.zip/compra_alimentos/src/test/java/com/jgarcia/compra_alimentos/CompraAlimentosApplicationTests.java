package com.jgarcia.compra_alimentos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompraAlimentosApplicationTests {

	@Test
	void contextLoads() {
	}

}
