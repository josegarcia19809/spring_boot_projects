package com.jgarcia.compra_alimentos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CompraAlimentosApplication {

	public static void main(String[] args) {
		SpringApplication.run(CompraAlimentosApplication.class, args);
	}

}
