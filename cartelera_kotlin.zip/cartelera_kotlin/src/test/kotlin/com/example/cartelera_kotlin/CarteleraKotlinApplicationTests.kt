package com.example.cartelera_kotlin

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class CarteleraKotlinApplicationTests {

	@Test
	fun contextLoads() {
	}

}
