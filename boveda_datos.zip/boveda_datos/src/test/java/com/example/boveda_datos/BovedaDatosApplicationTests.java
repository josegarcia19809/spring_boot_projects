package com.example.boveda_datos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BovedaDatosApplicationTests {

	@Test
	void contextLoads() {
	}

}
