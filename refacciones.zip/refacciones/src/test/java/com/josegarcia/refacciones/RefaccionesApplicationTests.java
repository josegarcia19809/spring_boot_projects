package com.josegarcia.refacciones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RefaccionesApplicationTests {

	@Test
	void contextLoads() {
	}

}
