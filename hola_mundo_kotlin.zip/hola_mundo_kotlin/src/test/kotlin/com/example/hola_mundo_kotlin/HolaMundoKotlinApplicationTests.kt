package com.example.hola_mundo_kotlin

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class HolaMundoKotlinApplicationTests {

	@Test
	fun contextLoads() {
	}

}
