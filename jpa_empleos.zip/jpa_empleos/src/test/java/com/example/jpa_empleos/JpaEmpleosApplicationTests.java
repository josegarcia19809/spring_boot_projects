package com.example.jpa_empleos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaEmpleosApplicationTests {

	@Test
	void contextLoads() {
	}

}
