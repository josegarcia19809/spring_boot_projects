package com.josegarcia.miPrimerApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiPrimerApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
