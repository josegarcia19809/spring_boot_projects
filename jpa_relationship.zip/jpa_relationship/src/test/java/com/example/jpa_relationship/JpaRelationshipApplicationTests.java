package com.example.jpa_relationship;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaRelationshipApplicationTests {

	@Test
	void contextLoads() {
	}

}
