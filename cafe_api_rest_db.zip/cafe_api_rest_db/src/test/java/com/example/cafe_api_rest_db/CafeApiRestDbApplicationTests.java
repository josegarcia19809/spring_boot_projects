package com.example.cafe_api_rest_db;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CafeApiRestDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
