package com.example.cafe_api_rest_db;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CafeApiRestDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(CafeApiRestDbApplication.class, args);
	}

}
